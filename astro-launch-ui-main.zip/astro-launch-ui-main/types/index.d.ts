declare module "prismjs/components/prism-core";
{
  var Paddle: any;
}
